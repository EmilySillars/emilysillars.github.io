DOG is a 2D Platformer created by Emily Sillars.

This game is available for free download at my website: emilysillars.github.io/DOG

All Images and animations copyright 2019 by Emily Sillars.


Music and Sound Effects Credits:

cicadas_crickets_night.aiff by patobottos: https://freesound.org/people/patobottos/sounds/178504/

Dog_howl_03.wav by CGEffex: https://freesound.org/people/CGEffex/sounds/158974/

Toy Accordion by avroshk: https://freesound.org/people/avroshk/sounds/339957/

Instrument_acordian_open.aif by vrodge: https://freesound.org/people/vrodge/sounds/119542/